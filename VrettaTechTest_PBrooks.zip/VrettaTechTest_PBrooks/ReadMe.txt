******************************
***********OVERVIEW***********
******************************

 - I made MathTap with Unity UI and 3D elements. I used C# for scripting.

 - The application file is VrettaTechTest_PBrooks.exe 

 - The data folder included with the .exe is required to run the program.

Since the application was made with Unity, it can also be quickly deployed to Android, iOS, WebGL, Facebook and more.


*****Implementation Details*****

The game mostly runs on Unity's UI interface consisting of 3 panels (start menu, gameplay, gameover) which are
animated using Unity's Mecanim.

High score is persisted between plays.

The white sphere contains a particle system to create the effect. It exists in 3D space and the game panels are 
displayed in the camera's frustum.

The game is managed by a "GameMaster" which uses a "QuestionMaster" to create questions and store their answer for
reference. 


I made the project available here for further reference
https://github.com/pbrooks04/MathTap


Thank you for your time. I wish you all the best and I look forward to hearing from you soon.

  Peter

